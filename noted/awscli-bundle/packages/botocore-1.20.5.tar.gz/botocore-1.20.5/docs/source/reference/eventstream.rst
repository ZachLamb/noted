.. _ref-eventstream:

==================
Event Stream Reference
==================

botocore.eventstream
-----------------

.. autoclass:: botocore.eventstream.EventStream
   :members:
